package com.box.boxandroidlibv2.exceptions;

/**
 * Interface for exceptions thrown from the box android library layer.
 */
public interface IBoxAndroidLibException {

}
